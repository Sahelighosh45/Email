import { Request, Response } from "express";
import { OAuth2Client } from "google-auth-library";
import jwt from "jsonwebtoken";
import { prisma } from "../db/prisma";
import type { User } from "@prisma/client";

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

/**
 * ============================
 * GOOGLE LOGIN
 * ============================
 */
export const googleLogin = async (req: Request, res: Response) => {
  try {
    const { idToken } = req.body as { idToken?: string };

    if (!idToken) {
      return res.status(400).json({ message: "idToken missing" });
    }

    // Verify Google token
    const ticket = await client.verifyIdToken({
      idToken,
      audience: process.env.GOOGLE_CLIENT_ID,
    });

    const payload = ticket.getPayload();
    if (!payload) {
      return res.status(401).json({ message: "Invalid Google token" });
    }

    const { sub, email, name, picture } = payload;

    if (!sub || !email) {
      return res.status(400).json({ message: "Incomplete Google profile" });
    }

    // Find or create user
    let user = await prisma.user.findUnique({
      where: { googleId: sub },
    });

    if (!user) {
      user = await prisma.user.create({
        data: {
          googleId: sub,
          email,
          name: name ?? "",
          avatar: picture ?? "",
        },
      });
    }

    // Issue JWT
    const token = jwt.sign(
      { userId: user.id },
      process.env.JWT_SECRET as string,
      { expiresIn: "7d" }
    );

    return res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
      },
    });
  } catch (err) {
    console.error("Google auth error:", err);
    return res.status(500).json({ message: "Google auth failed" });
  }
};

/**
 * ============================
 * GET LOGGED IN USER
 * ============================
 */
export const getMe = async (req: Request, res: Response) => {
  // req.user is set by auth middleware
  const user = req.user as User | undefined;

  if (!user) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  return res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    avatar: user.avatar,
  });
};
