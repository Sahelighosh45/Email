﻿import { Queue } from "bullmq";
import IORedis from "ioredis";

// If REDIS_URL is not provided, export nulls and make queue helpers no-ops so the
// HTTP server can start without Redis (useful for local dev or when worker runs separately).

export const connection: IORedis | null = process.env.REDIS_URL
  ? new IORedis(process.env.REDIS_URL, {
      // REQUIRED by BullMQ
      maxRetriesPerRequest: null,
      enableReadyCheck: false,

      // REQUIRED for Upstash
      tls: {
        rejectUnauthorized: false,
      },

      // Safe retry (BullMQ allows this)
      retryStrategy(times) {
        return Math.min(times * 100, 2000);
      },
    })
  : null;

if (connection) {
  connection.on("connect", () => {
    console.log("✅ Redis connected (BullMQ)");
  });

  connection.on("error", (err: any) => {
    console.error("❌ Redis error:", err.message || err);
  });
} else {
  console.warn("⚠️  REDIS_URL not set. Queue operations are disabled. Set REDIS_URL to enable BullMQ queues.");
}

// Define job data interface
export interface EmailJobData {
  emailJobId: string;
  hourlyLimit?: number;
  delayBetweenEmails?: number;
}

export const emailQueue: Queue<EmailJobData> | null = connection
  ? new Queue<EmailJobData>("email-queue", {
      connection,
      defaultJobOptions: {
        attempts: 5,
        backoff: {
          type: "exponential",
          delay: 5000,
        },
        removeOnComplete: true,
        removeOnFail: false,
      },
    })
  : null;

// Helper function to add email jobs with proper data
export async function addEmailJob(
  emailJobId: string,
  delayMs: number = 0,
  hourlyLimit?: number,
  delayBetweenEmails?: number
) {
  if (!emailQueue) {
    console.warn(`addEmailJob: queue disabled, skipping job add for ${emailJobId}`);
    return null;
  }

  const jobData: EmailJobData = {
    emailJobId,
    hourlyLimit,
    delayBetweenEmails,
  };

  const job = await emailQueue.add("process-email", jobData, {
    delay: delayMs > 0 ? delayMs : undefined,
    jobId: emailJobId, // Use emailJobId as jobId for uniqueness
  });

  console.log(`✅ Job added: ${job.id}, Delay: ${delayMs}ms, Hourly limit: ${hourlyLimit || 'default'}`);
  return job;
}

// Helper function to schedule bulk emails with delays
export async function scheduleBulkEmails(
  emailJobIds: string[],
  baseDelayMs: number = 0,
  delayBetweenEmailsMs: number = 0,
  hourlyLimit?: number
) {
  console.log(`📦 Scheduling ${emailJobIds.length} emails with hourlyLimit: ${hourlyLimit}`);

  if (!emailQueue) {
    console.warn("scheduleBulkEmails: queue disabled, skipping scheduling of jobs");
    return [];
  }

  const jobs = [];

  for (let i = 0; i < emailJobIds.length; i++) {
    const emailJobId = emailJobIds[i];
    const jobDelay = baseDelayMs + i * delayBetweenEmailsMs;

    const job = await addEmailJob(
      emailJobId,
      jobDelay,
      hourlyLimit,
      delayBetweenEmailsMs / (60 * 1000) // Convert ms to minutes for worker
    );

    jobs.push(job);

    console.log(`⏱️  Scheduled email ${i + 1}/${emailJobIds.length}: ${emailJobId}, Delay: ${jobDelay}ms, hourlyLimit: ${hourlyLimit}`);
  }

  return jobs;
}
