import "dotenv/config";
import { Worker, Job } from "bullmq";
import IORedis from "ioredis";
import { Resend } from "resend";
import { prisma } from "../db/prisma";
import { emailQueue, EmailJobData } from "../queues/email.queue";

/* =========================
   REDIS CONNECTION
========================= */
const redis = new IORedis(process.env.REDIS_URL!, {
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
  tls: { rejectUnauthorized: false },
});

/* =========================
   RESEND CLIENT
========================= */
if (!process.env.RESEND_API_KEY) {
  throw new Error("RESEND_API_KEY missing");
}

const resend = new Resend(process.env.RESEND_API_KEY);

/* =========================
   HELPERS
========================= */
function getHourKey(date: Date): string {
  return date.toISOString().slice(0, 13); // YYYY-MM-DDTHH
}

function getNextHour(): Date {
  const d = new Date();
  d.setHours(d.getHours() + 1, 0, 0, 0);
  return d;
}

/* =========================
   WORKER
========================= */
new Worker<EmailJobData>(
  "email-queue",
  async (job: Job<EmailJobData>) => {
    const { emailJobId, hourlyLimit } = job.data;

    console.log(`Processing job ${emailJobId} with hourlyLimit: ${hourlyLimit}`);

    const emailJob = await prisma.emailJob.findUnique({
      where: { id: emailJobId },
    });

    // Idempotency guard
    if (!emailJob || emailJob.status !== "SCHEDULED") {
      console.log(`Skipping job ${emailJobId} - status: ${emailJob?.status || 'not found'}`);
      return;
    }

    // Priority: job.data.hourlyLimit -> env variable -> default 1
    const MAX_PER_HOUR = hourlyLimit ?? (Number(process.env.MAX_EMAILS_PER_HOUR) || 1);
    console.log(`Using MAX_PER_HOUR: ${MAX_PER_HOUR} (from ${hourlyLimit !== undefined ? 'job data' : 'env/default'})`);

    const hourKey = getHourKey(new Date());
    const rateKey = `rate:${emailJob.senderEmail}:${hourKey}`;

    /* =========================
       ATOMIC RATE LIMIT CHECK
       - Increment FIRST (reserves slot atomically)
       - Then check if exceeded
       - Decrement if we need to reschedule
    ========================= */
    
    // Increment FIRST (atomic reservation)
    const newCount = await redis.incr(rateKey);

    // Set expiry only on first increment
    if (newCount === 1) {
      await redis.expire(rateKey, 3600);
    }

    console.log(`Current count for ${emailJob.senderEmail}: ${newCount}/${MAX_PER_HOUR}`);

    // Check if EXCEEDED
    if (MAX_PER_HOUR > 0 && newCount > MAX_PER_HOUR) {
      // Decrement to release the slot
      await redis.decr(rateKey);

      const nextHour = getNextHour();

      // Update DB so dashboard shows correct time
      await prisma.emailJob.update({
        where: { id: emailJob.id },
        data: {
          scheduledAt: nextHour,
        },
      });

      // Requeue job for next hour WITH hourlyLimit
      await emailQueue.add(
        "process-email",
        { 
          emailJobId,
          hourlyLimit
        },
        { delay: nextHour.getTime() - Date.now() }
      );

      console.log(
        `Rate limit hit (${newCount - 1}/${MAX_PER_HOUR}). Rescheduled ${emailJob.id} to ${nextHour.toISOString()}`
      );
      return;
    }

    /* =========================
       SEND EMAIL
       (Counter already incremented above)
    ========================= */
    try {
      await resend.emails.send({
        from: "ReachInbox <onboarding@resend.dev>",
        to: emailJob.recipientEmail,
        subject: emailJob.subject,
        text: emailJob.body,
      });

      // Update status after successful send
      await prisma.emailJob.update({
        where: { id: emailJob.id },
        data: {
          status: "SENT",
          sentAt: new Date(),
        },
      });

      console.log(
        `Email sent to ${emailJob.recipientEmail} (${newCount}/${MAX_PER_HOUR})`
      );
    } catch (error) {
      // Decrement counter on failure to free the slot
      await redis.decr(rateKey);

      // Update job status to FAILED
      await prisma.emailJob.update({
        where: { id: emailJob.id },
        data: {
          status: "FAILED",
        },
      });

      console.error(
        `Failed to send email to ${emailJob.recipientEmail}:`,
        error
      );
      throw error; // Let BullMQ handle retry logic
    }
  },
  {
    connection: redis,
    concurrency: 1,
  }
);

console.log("Email worker running with atomic rate limiting");