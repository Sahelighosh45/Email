// src/server.ts
import app from "./app";

const PORT = Number(process.env.PORT) || 4000;

app.listen(PORT, () => {
  console.log(` Server running on port ${PORT}`);
});

if (process.env.START_WORKER === "true") {
  import("./workers/email.worker");
}
