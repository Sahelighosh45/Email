# ReachInbox – Email Scheduling System

ReachInbox is a full-stack email-scheduling platform that supports single & bulk scheduling, rate limiting, configurable delays, and restart-safe persistence.

Built with Express, Prisma, BullMQ, Redis, PostgreSQL, and React.

## 🚀 Tech Stack

- **Backend:** Node.js, Express, Prisma (PostgreSQL), BullMQ (Redis), Nodemailer
- **Frontend:** React + TypeScript, CSS Modules
- **Auth:** JWT

## 🧠 Architecture Overview

Frontend (React) → Express API (Auth + Scheduling) → PostgreSQL (Prisma) (source of truth)
→ Redis (BullMQ delayed jobs) → Worker (Email sender)

## 🕒 How Email Scheduling Works

1. User schedules email(s) from the frontend.
2. Backend saves email metadata in PostgreSQL and enqueues a delayed job in BullMQ (Redis).
3. Worker picks the job at the scheduled time, applies rate limiting, sends the email via Nodemailer, and updates status (`SENT` / `FAILED`) in the DB.

## 🔁 Persistence & Restart Handling

- PostgreSQL is the single source of truth; Redis only holds timers.
- On server/worker restart:
  - Future scheduled emails still send.
  - Already sent emails are not re-sent.
  - Jobs resume correctly.

## 🚦 Rate Limiting & Concurrency

- **Rate limiting:** per-sender, per-hour (implemented using Redis counters). If the limit is exceeded, emails are rescheduled to the next available window.
- **Concurrency:** controlled by the BullMQ worker (`WORKER_CONCURRENCY`), e.g. `concurrency: 3`.

## 🛠 Backend Setup

1. Install dependencies

```bash
cd backend
npm install
```

2. Environment variables — create a `.env` file in `backend/` with values like:

```env
PORT=4000

DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DATABASE

REDIS_HOST=127.0.0.1
REDIS_PORT=6379

JWT_SECRET=super-secret-key

SMTP_HOST=smtp.ethereal.email
SMTP_PORT=587
SMTP_USER=YOUR_ETHEREAL_USER
SMTP_PASS=YOUR_ETHEREAL_PASS

MAX_EMAILS_PER_HOUR=30
MIN_DELAY_BETWEEN_EMAILS_MS=2000
WORKER_CONCURRENCY=3
```

3. Prisma (production-ready)

```bash
npx prisma generate
npx prisma migrate deploy
```

❗ Do NOT use `prisma migrate dev` in production.

4. Start Redis (Docker)

```bash
docker run -d -p 6379:6379 --name reachinbox-redis redis
```

5. Start backend services (separate terminals)

```bash
# API server
npx ts-node-dev src/server.ts

# Email worker
npx ts-node-dev src/workers/email.worker.ts
```

## 🧪 Ethereal Email Setup

1. Visit https://ethereal.email and create a test account.
2. Copy the SMTP credentials into your `.env` file.
3. Use the Ethereal inbox UI to view test emails.

## 🎨 Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

Create a `.env` in `frontend/`:

```env
VITE_API_URL=http://localhost:4000
```

## Features

- Google Login
- Dashboard (Scheduled / Sent emails)
- Compose email & CSV bulk upload
- Delay between emails, hourly rate limit, date/time scheduling
- Email detail page backed by the real API

## Backend Features

- Email scheduling: ✅
- Bulk CSV emails: ✅
- Delayed jobs: ✅
- Persistence on restart: ✅
- Rate limiting: ✅
- Concurrency control: ✅
- Worker separation: ✅
- Idempotent sending: ✅
